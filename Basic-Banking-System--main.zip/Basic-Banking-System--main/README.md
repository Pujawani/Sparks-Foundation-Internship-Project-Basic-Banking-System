# Basic-Banking-System-

## Introduction
>  ### The Sparks Foundation Internship Project - Basic Banking System
> A web application used to transfer money between two users.

## Technologies Used:
>  ### Front-End:
- HTML
- CSS
- Bootstrap
> ### Back-End:
-  PHP 
-  MYSQL

### Flow of the website
Home > View Customer > Select One Customer > Transfer Money > Select Receiver > View Customer

Below are the screenshots of the website

<img width="649" alt="1" src="https://user-images.githubusercontent.com/67001353/102710492-bc08e200-42d8-11eb-8709-631c7f12afc2.png">
<img width="645" alt="2" src="https://user-images.githubusercontent.com/67001353/102710493-bf03d280-42d8-11eb-96e0-85489c36fab0.png">


<img width="651" alt="3" src="https://user-images.githubusercontent.com/67001353/102710624-916b5900-42d9-11eb-8a88-169054aa948f.png">
<img width="668" alt="5" src="https://user-images.githubusercontent.com/67001353/102710627-96300d00-42d9-11eb-9021-94c177b0de18.png">
<img width="658" alt="4" src="https://user-images.githubusercontent.com/67001353/102710629-992afd80-42d9-11eb-9dce-f3186e282137.png">
